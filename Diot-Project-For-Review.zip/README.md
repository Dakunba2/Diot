# Diot — IoT 固件漏洞分析 Agent（基于 Agnes Harness 二开）

> 本包是给其他模型/开发者分析改进用的完整工程快照。
> **所有 API key、密码、token 已脱敏为 `REPLACE_*` 占位符**，运行前需自行填入。

---

## 一、这是什么

Diot 是一个**垂直服务 IoT 挖洞的 Agent**：在 Agnes Harness（AGH，一个本地 AI Agent 运行框架，带 Web UI / CLI / 插件 / MCP / 审批系统）基础上，把大脑换成"LIVA 式"的固件漏洞分析工作流，并外挂一套真实执行的分析工具链（ELF 解析、IDA 反编译、Neo4j 路径查询、taint 流水线）。

- **底座框架**：Agnes Harness（node/pnpm 工程，CLI + Web UI，插件系统，MCP 管理，审批与沙箱）
- **大脑**：`persona.md`（Diot 身份 + LIVA 7 步闭环）+ `coding-doctrine.md`（工程规范：证据选 ELF、附件工作流、跨 ELF 一等公民）
- **工具链**：`AGH-extension/diot-plugin`（AGH 插件，10 个工具），调用 `Diot/` 的 Python 分析核心
- **分析核心**：`Diot/`（自研，参考 `LIVA-reference/` 的 LIVA 原始实现）

## 二、包结构

```
diot_pack/
├── Diot/                  # Diot 分析核心（Python，AGH 插件调用它）
│   ├── diot.py            # 四阶段流水线入口（elf→danger→taint→infer）
│   ├── config/config.ini  # 配置（已脱敏）
│   ├── core/              # elf_parser / danger_func_analyzer / taint_analyzer / neo4j_opt / vulinfer ...
│   ├── core/llm/          # LLM 调用 + few-shot session
│   ├── skills/            # source_sink.py（动态 source/sink 发现）、cross_elf.py（跨 ELF + 验证闭环）
│   ├── memory/session.py  # 会话记忆
│   ├── bridge/ida_bridge.py # IDA 桥（HTTP，调 IDA 批处理反编译）
│   └── README.md          # Diot 工程自述
├── LIVA-reference/        # 原始 LIVA 论文实现（复现参考，Diot 的灵感来源）
│   ├── liva.py            # LIVA 四阶段流水线
│   ├── core/              # taint_path_finder / danger_func_analyzer / ghidra 分析器...
│   ├── bridge/ida_bridge.py
│   ├── scripts/           # IDA/Ghidra Java 脚本
│   └── utils/
├── AGH-extension/         # AGH 二开部分
│   ├── diot-plugin/       # AGH 插件（10 工具，index.mjs + package.json）
│   └── prompts/           # persona.md（Diot 大脑）+ coding-doctrine.md（规范）
└── README.md              # 本文件
```

## 三、核心工作流（LIVA 7 步闭环，已固化进 persona）

1. **Recon**：解包固件，清点 ELF，按攻击面证据选目标（httpd/cgibin/upnpd...），不凭习惯
2. **理解目标**：构建/加载调用图，映射入口（`*_main`、CGI handler）
3. **找 source**：攻击者可控数据入口（CGI 参数、POST body、环境变量）
4. **找 sink**：危险调用（system/popen/strcpy/sprintf/...）及包装函数
5. **追踪路径**：source→sink 数据流，解析间接调用（MIPS `jalr $t9`、GOT/PLT）
6. **跨 ELF 关联**：httpd→cgibin 跨二进制边界的数据流是一等公民
7. **验证**：可控性/可达性/长度/格式 + PoC 骨架，证据不完整就明说

## 四、关键经验（复现 LIVA 时踩坑沉淀，已固化的设计决策）

| 经验 | 固化位置 |
|---|---|
| 硬编码 source 函数名换固件即失效 → 动态发现 `*cgi_main` | `skills/source_sink.py` |
| wrapper sink 必须补入（lxmldbc_system 是 CVE-2025-7836 引信） | `skills/source_sink.py` merge_sink_set |
| 间接调用不解析 → 调用图 88 vs 277 函数（MIPS jalr $t9） | IDA 桥 /callgraph |
| 空返回重试 + 指数退避 | `core/taint_analyzer.py` |
| checkpoint/--resume 断点续跑（LLM 长任务） | `diot.py` |
| 跨 ELF KNOWN_DISPATCH 映射（httpd→cgi_main 对应多 CVE） | `skills/cross_elf.py` |
| 数据流存在 ≠ 漏洞，必须验证闭环 | `skills/cross_elf.py` verification_loop |
| 附件是虚拟路径必须先落盘 | `AGH-extension/diot-plugin` 的 diot_export_attachment + coding-doctrine |
| 分析脚本用 venv python（裸 python 是坏运行时） | coding-doctrine |

## 五、AGH 插件工具清单（10 个）

`diot_elf_info` `diot_callgraph` `diot_source_discovery` `diot_sink_scan` `diot_verify` `diot_cross_elf` `diot_neo4j_paths` `diot_taint_analyze` `diot_read_artifacts` `diot_export_attachment`

插件通过 `context.session.readAttachment` 读会话附件，`runPython` 子进程调用 `Diot/` 核心（`DIOT_PYTHON`/`DIOT_ROOT` 环境变量可覆盖路径）。

## 六、已知问题 / 待改进点（重要）

1. **模型能力是最大瓶颈**：当前用 `agnes-3.0-flash`，实测"瞎猜不查证/工具选择混乱/无进展感知/放弃甩锅"，把简单配置问题绕 1 小时。**换强推理模型（DeepSeek V3/R1、Claude 等）是治本方向**——底座框架已接好，只差换 provider。
2. **MCP 配置脆弱**：ida_bridge/neo4j 的 executable 路径曾指向失效沙箱 python，需保证指向 venv python。
3. **插件改代码后必须重装**：AGH 插件是复制到 `~/.agh/data/profiles/<profile>/packages/<id>/` 运行的，改源码后需 `package add/trust/enable` 重新同步，否则 lock integrity 失配 daemon 起不来。
4. **附件落盘已修**：`diot_export_attachment` 把 `session-file://` 虚拟附件导出到真实磁盘；但模型是否主动走此流程仍依赖模型能力。
5. **端到端未实测**：工具链就绪 + diot.py 预编排流水线 smoke 通过，但模型驱动完整挖洞流程未在 Web 会话实测。
6. **跨 ELF 断链**：历史 CVE 集中在 cgibin，选错分析对象（如选 httpd）会全部漏掉——已有 coding-doctrine 引导 + 动态 source，但跨二进制 taint 仍需人工确认。

## 七、运行方式（简略）

```bash
# 环境：node 24 + pnpm + venv python（Diot/LIVA 的 .venv）
# 1. 构建 AGH（提示词改动需重建）
cd agnes-harness-main
$env:AGNES_NODE_HEADERS = "path/to/node-headers"
pnpm --filter @agnes/cli build:local
# 2. 启动服务
node packages/cli/dist/local/agnes.mjs serve --profile local-dev   # Web UI :4177
# 3. 依赖服务
#    IDA 桥: venv uvicorn ida_bridge:app --port 8082
#    Neo4j:  neo4j.bat console  (bolt://localhost:7687)
# 4. 插件安装（改代码后必做）
node packages/cli/dist/local/agnes.mjs package add file:./examples/packages/diot-plugin --profile local-dev
node packages/cli/dist/local/agnes.mjs package trust @diot/iot-plugin <integrity> <capabilityHash> --profile local-dev
node packages/cli/dist/local/agnes.mjs package enable @diot/iot-plugin --profile local-dev
```

## 八、目标

给分析者一句话：**Diot = AGH 框架（执行/审批/UI/插件）+ LIVA 方法论（7 步闭环）+ 真实工具链（IDA/Neo4j/pyelftools）+ 复现经验固化（动态发现/验证闭环/跨 ELF）**。当前短板在模型推理能力，框架与工具链已就绪。

---
*打包时间：2026-10-11。密钥已脱敏，运行时需自配。*
