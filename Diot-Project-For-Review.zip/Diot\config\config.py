import os
import configparser
import json
from sqlalchemy.orm import sessionmaker
from sqlalchemy import create_engine, Column, String, Integer
from sqlalchemy.ext.declarative import declarative_base
from datetime import datetime
from utils.utils import ensure_directory_exists, get_md5_prefix, upsert_ProjectInfo_data

# Diot 根目录（本文件位于 config/ 下）
HOME = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
GHIDRA_SCRIPT_ROOT_PATH = os.path.join(HOME)
# ghidra path（保留，Diot 已全 IDA 化，仅作兜底）
HEADLESS_GHIDRA = os.path.join(HOME, "ghidra_12.1.4_PUBLIC", "support", "analyzeHeadless.bat")
GHIDRA_SCRIPT = os.path.join(HOME, "headless")
_engine = None
_Session = None
Base = declarative_base()
neo4j_paths = None
lib_sink = None


class ProjectInfo(Base):
    __tablename__ = 'project_info'
    tag = Column(String, primary_key=True)
    data = Column(String)


class LibUnsafeResJson(Base):
    __tablename__ = 'lib_unsafe_res_json'
    lib_file_name = Column(String, primary_key=True)
    result_json = Column(String)


class LibDecompileResJson(Base):
    __tablename__ = 'lib_decompile_res'
    id = Column(Integer, primary_key=True, autoincrement=True)
    lib_name = Column(String, nullable=False)
    func_name = Column(String, nullable=False)
    func_addr = Column(String, nullable=False)
    decompiled_code = Column(String, nullable=False)


class Config:
    def __init__(self, config_file='config/config.ini'):
        self.config = self.load_config(config_file)
        self.scripts = self.generate_scripts_config()
        self.vfuncParam = self.load_vfuncParam()
        self.project_name = None
        self.project_path = None
        self.binary_path = None
        self.lib_path = f"result/{self.config['ResultDir']['lib_path']}"
        self.directory_map = None
        self.other_config = {}
        self.main_project_name = None
        self.main_file_name = None
        self.db_path = None
        self.device = None
        self.source_point = []
        self.sink_point = []

    def set_device_info(self, device):
        self.device = device
        self.project_path = device
        self.db_path = f"result/{device}/ghidra_analyze_res.db"

    def init_db(self):
        tag = "LastTime"
        data = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        upsert_ProjectInfo_data(tag, data)

    def get_db_session(self, Base):
        global _engine, _Session
        if _engine is None or _Session is None:
            _engine = create_engine(f"sqlite:///{self.db_path}")
            Base.metadata.create_all(_engine)
            _Session = sessionmaker(bind=_engine)
        return _Session()

    def set_binary_path(self, binary_path, main_file):
        self.binary_path = binary_path
        self.set_project_name(main_file)

    def set_project_name(self, main_file):
        file_name = os.path.basename(self.binary_path)
        file_md5_prefix = get_md5_prefix(self.binary_path)
        self.other_config[file_name] = f"{file_name}_{file_md5_prefix}"
        self.project_name = os.path.join(self.config['ResultDir']['lib_path'], f"{file_name}_{file_md5_prefix}") if main_file else f"{file_name}_{file_md5_prefix}"
        if not main_file:
            self.main_project_name = self.project_name
            self.main_file_name = file_name
        self.set_directory_map()

    def load_config(self, config_file):
        config = configparser.ConfigParser()
        config.read(config_file)
        return config

    def export_vulconfig_function(self):
        if 'VulFunction' not in self.config:
            print("No 'VulFunction' section found in config.")
            return {}
        vul_functions = self.config['VulFunction']
        function_data = {}
        for category, functions in vul_functions.items():
            function_data[category] = functions.split(', ')
        return function_data

    def generate_scripts_config(self):
        scripts = {}
        for name, file in self.config["Script"].items():
            scripts[name] = os.path.join(GHIDRA_SCRIPT_ROOT_PATH, file)
        return scripts

    def load_vfuncParam(self):
        vparam = self.config['VulFunction']['param']
        return json.loads(vparam)

    def set_directory_map(self):
        self.directory_map = {
            "elfParse": os.path.join(self.config["ResultDir"]["root"], self.device, self.project_name, self.config["ResultDir"]["elf_parse"]),
            "binary": os.path.join(self.config["ResultDir"]["root"], self.device, self.project_name, self.config["ResultDir"]["iot_file"]),
            "ghidra": os.path.join(self.config["ResultDir"]["root"], self.device, self.project_name, self.config["ResultDir"]["ghidra"]),
        }
        for directory in self.directory_map.values():
            ensure_directory_exists(directory)


LivaConfig = Config()

if __name__ == "__main__":
    print(LivaConfig.export_vulconfig_function())
    print(HOME)
