# Diot

**个人 IoT 固件漏洞分析 Agent 工程** —— 以 Agnes Harness (AGH) 为架构蓝本，整合 LIVA（IEEE TDSC 2026 论文复现）全部实战经验。

> 一句话：把"在 DIR-816L 上从挖不出 CVE 到复现出 11 条历史 CVE"的整个过程，固化成一台可复用的 agent。

---

## 为什么叫 Diot / 为什么有它

复现 LIVA 论文（`D:\专利\LIVA_*.pdf`）时走了完整七阶段流水线（elf→source→sink→danger→taint→neo4j→infer），前 90% 时间都在交学费：

| 阶段 | 踩坑 | 修法 | 沉淀到 Diot |
|---|---|---|---|
| Ghidra 调用图 | MIPS `lw $t9; jalr $t9` 间接调用解析失败 → 277 个函数只进 88 个 | 全量换 IDA 提取调用图（277 函数） | `skills/source_sink.py` + IDA 桥 |
| source 起点 | 硬编码 `process_request/process_cgi`（httpd 函数名），cgibin 里没有 → 路径 0 | 动态发现图中所有 `*main` 入口（15 个 cgi_main） | `dynamic_source_discovery()` |
| sink 列表 | `lxmldbc_system` 不在默认 sink 表（它是包装函数，内部 vsnprintf+system）→ CVE-2025-7836 链断 | 补入包装 sink | `wrapper_sink_enrichment()` |
| taint 长跑 | 268 条逐条 LLM 分析，单进程跑 3.4 小时，断网就全丢 | 逐条 checkpoint 落盘，崩了续跑 | `memory/session.py::Checkpoint` |
| LLM 空返回 | 模型对超长请求偶发空返回 → 整条分析作废 | 空串也走重试 | 已内建到 `core/llm/llm_request.py` |
| 跨 ELF | httpd 是分发层，CVE 靶点全在 cgibin，单 ELF 分析器看不到 | 手动换 cgibin 分析对象 | `skills/cross_elf.py::build_cross_elf_model` |
| 验证闭环 | "数据流存在" ≠ 漏洞，LIVA 只有 Yes/No | 需要可控性/长度/可达性/PoC | `skills/cross_elf.py::verification_loop` |

最终在 cgibin 上复现出 **41 条路径 / 13 条报告 / 11 条 GPT 判定 Yes**，命中 CVE-2025-7836（lxmldbc_system 命令注入）、CVE-2025-13188（认证栈溢出）、CVE-2025-9727/13191（soap.cgi）等。

---

## 架构：AGH 四角色映射

以 AGH 的"大脑 / 小脑 / 记忆 / 身体"为蓝本，Diot 落地为四层：

```
┌────────────────────────────────────────────────────────┐
│  Agent Loop (core/agent_loop.py)   ← 大脑：阶段编排      │
│    拓扑排序 · 失败隔离 · --resume 跳过已完成 · 全量留痕    │
├────────────────────────────────────────────────────────┤
│  Plugins (core/plugins.py + stages) ← 插件：能力即插件   │
│    elf / source / sink / danger / taint / neo4j / infer │
│    每个阶段是独立插件，注册表驱动，可插拔可裁剪          │
├────────────────────────────────────────────────────────┤
│  Skills (skills/)                  ← 方法论：经验固化     │
│    source_sink.py   动态 source + wrapper sink 补入      │
│    cross_elf.py     跨 ELF 攻击面模型 + 验证闭环 + PoC    │
├────────────────────────────────────────────────────────┤
│  Harness 记忆 (memory/session.py)  ← 记忆：会话与断点     │
│    DiotContext 会话上下文 · SessionLedger 执行记录       │
│    Checkpoint 崩溃安全断点（taint 长跑保命）             │
├────────────────────────────────────────────────────────┤
│  身体 (bridge/ + Neo4j + IDA)      ← MHS：外部能力        │
│    IDA 桥 FastAPI :8082（调用图+反编译）                 │
│    Neo4j 图数据库（路径查询）                           │
└────────────────────────────────────────────────────────┘
```

- **LLM = 大脑**：经 `core/llm/llm_request.py`（OpenAI 兼容，当前 agnes-3.0-flash）
- **Plugins = 业务能力**：每个分析阶段一个插件，`diot.py --stages elf,taint,neo4j,infer` 按需组装
- **Skills = 可复用方法**：把踩坑修法写死成函数，换固件不换逻辑
- **Harness = 记忆**：产物路径、执行记录、断点全部落盘，`--resume` 复盘

---

## 快速开始

### 环境
- Python venv（复用 LIVA 的）：`D:\AgentLearning\IOT Agent\LIVA\.venv\Scripts\python.exe`
- Neo4j：`neo4j / REPLACE_NEO4J_PASSWORD`，Bolt 7687 + HTTP 7474
- IDA 桥：`bridge/ida_bridge.py`（FastAPI :8082，token `REPLACE_IDA_TOKEN`）

### 完整跑（新固件）
```powershell
cd D:\AgentLearning\IOT Agent\Diot
& D:\AgentLearning\IOT Agent\LIVA\.venv\Scripts\python.exe diot.py `
    <binary> <rootfs_dir> <device> --stages all
```

### 用已有产物续跑（跳过 taint 长跑）
```powershell
& D:\AgentLearning\IOT Agent\LIVA\.venv\Scripts\python.exe diot.py `
    D:\AgentLearning\IOT Agent\firmware\rootfs\cgibin `
    D:\AgentLearning\IOT Agent\firmware\rootfs `
    DIR816L-cgibin-smoke `
    --stages neo4j,infer `
    --callgraph C:\Users\Lenovo\AppData\Local\Temp\ida_bridge\cgibin_callgraph.json `
    --taint   D:\AgentLearning\IOT Agent\LIVA\result\DIR816L-cgibin\cgibin_6520c5\taint_analysis.json `
    --decompile D:\AgentLearning\IOT Agent\LIVA\result\DIR816L-cgibin\cgibin_6520c5\parent_child_calls_ida_decompile.json
```

### 常用选项
| 选项 | 作用 |
|---|---|
| `--stages a,b,c` | 只跑指定阶段（依赖自动排序） |
| `--resume` | 跳过本会话已完成阶段 |
| `--callgraph <json>` | 跳过 live IDA，用已有调用图 |
| `--taint <json>` | 跳过 taint 长跑，用已有产物 |
| `--decompile <json>` | 指定反编译产物（infer 需要） |
| `--dry-run` | 打印执行计划不执行 |

---

## 阶段产物

`result/<device>/<binary>/` 下：

| 文件 | 阶段 | 内容 |
|---|---|---|
| `source_points.json` | source | 动态发现的入口函数 |
| `sink_points.json` | sink | 危险函数 + wrapper 补入 |
| `parent_child_calls.json` | danger | 调用图父子关系 |
| `taint_analysis.json` | taint | LLM 逐条 taint 结果（checkpoint） |
| `neo4j_paths.json` | neo4j | source→sink 路径 |
| `cmd_injection_candidates.txt` | infer | 候选报告 |
| `vul_result.txt` | infer | GPT 判定（Yes/No） |

`diot_ledger.jsonl` 记录每个阶段执行结果（ok/summary/artifacts/elapsed），复盘入口。

---

## 关键设计决策

### 1. 为什么用 Python 而不是在 AGH 的 TS 代码上改
AGH 是 pnpm workspace TS monorepo（Node ≥24.10，含 CLI/Web/SDK），而 LIVA 核心（IDA 桥、Neo4j 客户端、LLM 请求）全在 Python venv 里。Diot **以 AGH 的架构为蓝本、Python 落地**：保留 AGH 的"插件 + 记忆 + 方法论"组织方式，复用已验证的分析核心，避免"把跑通的东西用 TS 重写一遍"带来的回归风险。

### 2. source 必须动态发现
硬编码函数名是最大的隐蔽杀手。`dynamic_source_discovery()` 从调用图自动找 `*cgi_main / *main` 入口，任何固件都适用。

### 3. wrapper sink 必须补入
`lxmldbc_system` 这类包装函数内部调 `system`，但不在 libc sink 表。`wrapper_sink_enrichment()` 把已知 wrapper 和调用图实测命中的 sink 合并，CVE-2025-7836 链才闭合。

### 4. 数据流 ≠ 漏洞
`verification_loop()` 对每条候选做可控性/长度/可达性检查，输出 `likely_vuln / need_poc / unverified` 三档，并给出 PoC 骨架——这是 LIVA 没有的验证闭环。

### 5. 跨 ELF 是架构空白
单 ELF 分析器看不到 httpd→cgibin 的跨文件数据流。`build_cross_elf_model()` 把主程序分发层与 CGI 处理 ELF 的攻击面建模，指出"该分析哪个 ELF"。

---

## 与 LIVA 的关系

| | LIVA | Diot |
|---|---|---|
| 阶段编排 | liva.py 里一串 if-else | 插件注册表 + 拓扑排序 |
| 状态传递 | 全局变量 | DiotContext + ledger |
| 长跑安全 | 无 checkpoint（跑完才落盘） | 逐条 checkpoint + resume |
| source | 硬编码 | 动态发现 |
| sink | 固定表 | 调用图实测 + wrapper 补入 |
| 验证 | 只有 Yes/No | 可控性/长度/可达性 + PoC |
| 跨 ELF | 不支持 | 攻击面建模 |
| 复用 | — | 核心分析逻辑直接复用 LIVA 修复版 |

## 下一步（建议迭代顺序）
1. 接入 AGH 的 MCP 概念：把 IDA 桥 / Neo4j 注册成 MCP 工具，让 LLM 能直接调用
2. 多固件批量：`--stages all` 对一批固件循环
3. 报告 HTML 化：vul_result 输出可视化报告
4. 接 AGH Web/CLI 会话恢复（借鉴 `/resume <id>` 语义）
